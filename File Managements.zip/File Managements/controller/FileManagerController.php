<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\File;
use App\Models\Folder;

class FileManagerController extends Controller
{
    public function index()
    {
        $folders = Folder::with('files')->get();
        return view('file_manager.index', compact('folders'));
    }

    public function createFolder(Request $request)
    {
        $request->validate([
            'name' => 'required|string|unique:folders,name',
        ]);

        Folder::create(['name' => $request->name]);

        return back()->with('success', 'Folder created.');
    }

   public function uploadFile(Request $request, Folder $folder)
    {
        $request->validate([
            'file' => 'required|file|max:10240',
        ]);

        $file = $request->file('file');
        $filename = time() . '_' . $file->getClientOriginalName();
        $destinationPath = public_path('uploads/folder_' . $folder->id);

        if (!file_exists($destinationPath)) {
            mkdir($destinationPath, 0755, true);
        }

        $file->move($destinationPath, $filename);

        $folder->files()->create([
            'filename' => $filename,
            'filepath' => 'uploads/folder_' . $folder->id . '/' . $filename,
        ]);

        return back()->with('success', 'File uploaded.');
    }

    public function store(Request $request)
    {
        $request->validate([
            'folder_id' => 'required|exists:folders,id',
            'files.*' => 'required|file|max:10240',
        ]);

        $folderId = $request->folder_id;
        $folder = Folder::findOrFail($folderId);
        $destinationPath = public_path('uploads/folder_' . $folderId);

        if (!file_exists($destinationPath)) {
            mkdir($destinationPath, 0755, true);
        }

        foreach ($request->file('files') as $file) {
            $filename = time() . '_' . $file->getClientOriginalName();
            $file->move($destinationPath, $filename);

            $folder->files()->create([
                'filename' => $file->getClientOriginalName(),
                'filepath' => 'uploads/folder_' . $folderId . '/' . $filename,
            ]);
        }

        return redirect()->back()->with('success', 'Files uploaded successfully.');
    }

  public function downloadFile($id)
    {
        $file = File::findOrFail($id);
        $path = public_path($file->filepath);

        if (file_exists($path)) {
            return response()->download($path, $file->filename);
        }

        return back()->with('error', 'File not found.');
    }
	public function destroy($id)
{
    $file = File::findOrFail($id);

    if (file_exists(public_path($file->filepath))) {
        unlink(public_path($file->filepath));
    }

    $file->delete();

    return redirect()->back()->with('success', 'File deleted successfully.');
}

}
