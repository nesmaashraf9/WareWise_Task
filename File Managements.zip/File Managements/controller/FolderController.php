<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Folder;
use Illuminate\Support\Facades\Storage;

class FolderController extends Controller
{
    public function index()
    {
        $folders = Folder::all();
        return view('folders.index', compact('folders'));
    }

    public function create()
    {
        return view('folders.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|unique:folders,name',
        ]);

        $folder = new Folder();
        $folder->name = $request->name;
        $folder->save();

        // Create the folder in storage (optional but useful)
        Storage::makeDirectory('uploads/' . $folder->name);

        return redirect()->route('folders.index')->with('success', 'Folder created successfully.');
    }

    public function show(Folder $folder)
    {
        $files = Storage::files('uploads/' . $folder->name);
        return view('folders.show', compact('folder', 'files'));
    }

    public function upload(Request $request, Folder $folder)
{
    $request->validate([
        'file' => 'required|file|max:10240',
    ]);

    $destinationPath = public_path('uploads/folder_' . $folder->id);

    if (!file_exists($destinationPath)) {
        mkdir($destinationPath, 0755, true);
    }

    $file = $request->file('file');
    $filename = time() . '_' . $file->getClientOriginalName();
    $file->move($destinationPath, $filename);

    $folder->files()->create([
        'filename' => $filename,
        'filepath' => 'uploads/folder_' . $folder->id . '/' . $filename,
    ]);

    return back()->with('success', 'File uploaded successfully.');
}

	public function edit(Folder $folder)
{
    return view('folders.edit', compact('folder'));
}
	public function update(Request $request, Folder $folder)
{
    $request->validate([
        'name' => 'required|string|unique:folders,name,' . $folder->id,
    ]);

    // Rename the folder in storage if the name changed
    if ($folder->name !== $request->name) {
        Storage::move('uploads/' . $folder->name, 'uploads/' . $request->name);
    }

    $folder->name = $request->name;
    $folder->save();

    return redirect()->route('folders.index')->with('success', 'Folder updated successfully.');
}

	public function destroy(Folder $folder)
{
    // Delete the folder from storage
    Storage::deleteDirectory('uploads/' . $folder->name);

    // Delete from DB
    $folder->delete();

    return redirect()->route('folders.index')->with('success', 'Folder deleted successfully.');
}
}
