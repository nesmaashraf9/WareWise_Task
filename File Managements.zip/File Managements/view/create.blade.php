@extends('layouts.default')

@section('title', 'Create Folder')

@section('content')
<style>
    .create-folder-card {
        background: #fff;
        border-radius: 12px;
        box-shadow: 0 0 10px rgba(0,0,0,0.05);
        padding: 25px;
        max-width: 600px;
        margin: 40px auto;
    }

    .create-folder-header {
        font-size: 20px;
        font-weight: 600;
        color: #2c3e50;
        margin-bottom: 20px;
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .form-label {
        font-weight: 500;
        color: #2c3e50;
        margin-bottom: 6px;
    }

    .form-control {
        border-radius: 6px;
        padding: 10px;
        border: 1px solid #ced4da;
    }

    .btn-create {
        background-color: #3c8dbc;
        color: white !important;
        border: none;
        padding: 10px 20px;
        border-radius: 6px;
        font-weight: 500;
    }

    .alert-success {
        background-color: #d4edda;
        color: #155724;
        border-radius: 6px;
        padding: 10px 15px;
        margin-bottom: 20px;
        border: 1px solid #c3e6cb;
    }
</style>

<div class="create-folder-card">
    <div class="create-folder-header">
        <i class="fas fa-folder-plus text-primary"></i>
        Create New Folder
    </div>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <form method="POST" action="{{ route('folders.store') }}">
        @csrf
        <div class="mb-3">
            <label for="name" class="form-label">Folder Name</label>
            <input type="text" class="form-control" name="name" required>
        </div>
        <button type="submit" class="btn-create">
            <i class="fas fa-check-circle me-1"></i> Create Folder
        </button>
    </form>
</div>
@endsection
