@extends('layouts.default')

@section('title', 'Edit Folder')

@section('content')
<style>
    .edit-folder-card {
        background: #fff;
        border-radius: 12px;
        box-shadow: 0 0 10px rgba(0,0,0,0.05);
        padding: 30px;
        max-width: 600px;
        margin: 0 auto;
    }

    .edit-folder-header {
        font-size: 20px;
        font-weight: 600;
        color: #2c3e50;
        margin-bottom: 20px;
    }

    .form-label {
        font-weight: 500;
        color: #2c3e50;
    }

    .form-control {
        border-radius: 8px;
        border: 1px solid #ccc;
        padding: 10px 15px;
        font-size: 14px;
    }

    .form-actions {
        margin-top: 25px;
    }

    .btn-update {
        background-color: #3c8dbc;
        color: white;
        border: none;
        padding: 10px 20px;
        border-radius: 6px;
        font-weight: 500;
        margin-right: 10px;
    }

    .btn-cancel {
        background-color: #6c757d;
        color: white;
        border: none;
        padding: 10px 20px;
        border-radius: 6px;
        font-weight: 500;
    }

    .btn-update:hover {
        background-color: #337ab7;
    }

    .btn-cancel:hover {
        background-color: #5a6268;
    }
</style>

<div class="container mt-4">
    <div class="edit-folder-card">
        <div class="edit-folder-header">
            <i class="fas fa-edit text-primary me-2"></i> Edit Folder
        </div>
        <form action="{{ route('folders.update', $folder->id) }}" method="POST">
            @csrf
            @method('PUT')

            <div class="mb-3">
                <label for="name" class="form-label">Folder Name</label>
                <input type="text" name="name" class="form-control" value="{{ $folder->name }}" required>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn-update">
                    <i class="fas fa-save me-1"></i> Update
                </button>
                <a href="{{ route('folders.index') }}" class="btn-cancel">
                    <i class="fas fa-times me-1"></i> Cancel
                </a>
            </div>
        </form>
    </div>
</div>
@endsection
