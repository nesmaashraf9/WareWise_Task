@extends('layouts.default')

@section('title', 'Folders Table')

@section('content')
<style>
    .folders-card {
        background: #fff;
        border-radius: 12px;
        box-shadow: 0 0 10px rgba(0,0,0,0.05);
        padding: 25px;
    }

    .folders-header {
        font-weight: 600;
        font-size: 18px;
        color: #2c3e50;
        margin-bottom: 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .btn-add-folder {
        background-color: #3c8dbc;
        color: white !important;
        border: none;
        padding: 6px 16px;
        border-radius: 6px;
        font-weight: 500;
    }

    .btn-edit {
        background-color: #17a2b8;
        color: white;
        border: none;
        padding: 6px 10px;
        border-radius: 6px;
    }

    .btn-view {
        background-color: #ffc107;
        color: #000;
        border: none;
        padding: 6px 10px;
        border-radius: 6px;
        margin-right: 6px;
    }

    .btn-delete {
        background-color: #dc3545;
        color: white;
        border: none;
        padding: 6px 10px;
        border-radius: 6px;
    }

    .custom-table {
        width: 100%;
        border-collapse: collapse;
    }

    .custom-table th,
    .custom-table td {
        border: 1px solid #dee2e6;
        padding: 12px;
        text-align: center;
        vertical-align: middle;
    }

    .custom-table thead {
        background-color: #f8f9fa;
        font-weight: bold;
    }

    .custom-table tbody tr:hover {
        background-color: #f1f1f1;
    }

    .file-count-badge {
        background-color: #ffc107;
        color: #000;
        padding: 4px 10px;
        font-size: 12px;
        border-radius: 12px;
    }

    .folder-icon {
        color: #f4b400;
        margin-right: 8px;
    }
</style>

<div class="container mt-4">
    <div class="folders-card">
        <div class="folders-header">
            <div>
                <i class="fas fa-folder text-primary me-2"></i>
                Folders Table
            </div>
            <a href="{{ route('folders.create') }}" class="btn-add-folder">
                <i class="fas fa-folder-plus me-1"></i> Create Folder
            </a>
        </div>

        @if($folders->isEmpty())
            <p>No folders found.</p>
        @else
            <table class="custom-table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Folder Name</th>
                        <th>Files</th>
                        <th>Created At</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($folders as $index => $folder)
                        <tr>
                            <td>{{ $index + 1 }}</td>
                            <td>
                                <i class="fas fa-folder folder-icon"></i>
                                <a href="{{ route('folders.show', $folder->id) }}" style="color: #2c3e50; font-weight: 500;">
                                    {{ $folder->name }}
                                </a>
                            </td>
                            <td>
                                <span class="file-count-badge">{{ $folder->files_count }} files</span>
                            </td>
                            <td>{{ $folder->created_at->format('M d, Y H:i') }}</td>
                            <td>
                                <div style="display: flex; gap: 8px; justify-content: center; align-items: center;">
                                    <a href="{{ route('folders.show', $folder->id) }}" class="btn-view" title="View">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="{{ route('folders.edit', $folder->id) }}" class="btn-edit" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <form action="{{ route('folders.destroy', $folder->id) }}" method="POST" onsubmit="return confirm('Are you sure?');" style="display: inline;">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn-delete" title="Delete">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        @endif
    </div>
</div>
@endsection
