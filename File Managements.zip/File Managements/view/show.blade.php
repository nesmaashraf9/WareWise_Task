@extends('layouts.default')

@section('title', 'Folder Files')

@section('content')
<style>
    .folder-card {
        background: #fff;
        border-radius: 12px;
        box-shadow: 0 0 10px rgba(0,0,0,0.05);
        padding: 25px;
        position: relative;
    }

    .folder-header {
        font-weight: 600;
        font-size: 18px;
        color: #2c3e50;
        margin-bottom: 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .btn-back {
        background-color: #6c757d;
        color: white !important;
        border: none;
        padding: 6px 16px;
        border-radius: 6px;
        font-weight: 500;
        text-decoration: none;
    }

    .btn-upload {
        background-color: #28a745;
        color: white !important;
        border: none;
        padding: 6px 16px;
        border-radius: 6px;
        font-weight: 500;
        cursor: pointer;
    }

    .btn-view {
        background-color: #007bff;
        color: white;
        border: none;
        padding: 6px 10px;
        border-radius: 6px;
        margin-right: 6px;
    }

    .btn-download {
        background-color: #17a2b8;
        color: white;
        border: none;
        padding: 6px 10px;
        border-radius: 6px;
    }

    .custom-table {
        width: 100%;
        border-collapse: collapse;
    }

    .custom-table th,
    .custom-table td {
        border: 1px solid #dee2e6;
        padding: 12px;
        text-align: center;
        vertical-align: middle;
    }

    .custom-table thead {
        background-color: #f8f9fa;
        font-weight: bold;
    }

    .custom-table tbody tr:hover {
        background-color: #f1f1f1;
    }

    .upload-form {
        position: absolute;
        top: 25px;
        right: 25px;
    }

    .hidden-file-input {
        display: none;
    }
</style>

<div class="container mt-4">
    <div class="folder-card">
        <div class="folder-header">
            <div>
                <i class="fas fa-folder-open text-primary me-2"></i>
                Folder: {{ $folder->name }}
            </div>
           
        </div>

    <form id="uploadForm" action="{{ route('files.store') }}" method="POST" enctype="multipart/form-data" style="position: absolute; top: 20px; right: 20px;">
    @csrf
    <input type="hidden" name="folder_id" value="{{ $folder->id }}">

    {{-- Hidden File Input --}}
    <input type="file" name="files[]" id="fileInput" multiple style="display: none;" onchange="document.getElementById('uploadForm').submit();" required>

    {{-- Upload Button --}}
    <button type="button" class="btn-upload" onclick="document.getElementById('fileInput').click();">
        <i class="fas fa-upload"></i> Upload
    </button>
</form>



        {{-- File List --}}
        @if($folder->files->count())
            <table class="custom-table mt-4">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Filename</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($folder->files as $index => $file)
                        <tr>
                            <td>{{ $index + 1 }}</td>
                            <td>{{ $file->filename }}</td>
                            <td>
    <div style="display: flex; gap: 8px; justify-content: center; align-items: center;">
        {{-- View Icon --}}
        <a href="{{ asset($file->filepath) }}" target="_blank" class="btn-view" title="View">
            <i class="fas fa-eye"></i>
        </a>

        {{-- Download Icon --}}
        <a href="{{ route('file.download', $file->id) }}" class="btn-download" title="Download">
            <i class="fas fa-download"></i>
        </a>

        {{-- Delete Icon --}}
        <form action="{{ route('file.delete', $file->id) }}" method="POST" style="display:inline;">
            @csrf
            @method('DELETE')
            <button type="submit" class="btn btn-danger" style="padding: 6px 10px; border-radius: 6px;" title="Delete" onclick="return confirm('Are you sure you want to delete this file?');">
                <i class="fas fa-trash"></i>
            </button>
        </form>
    </div>
</td>

                        </tr>
                    @endforeach
                </tbody>
            </table>
        @else
            <p class="mt-3">No files uploaded yet.</p>
        @endif
    </div>
</div>

@endsection
