<?php

namespace App\Http\Controllers;

use App\Models\InnerLocation;
use Illuminate\Http\Request;

class InnerLocationController extends Controller
{
    /**
     * Display a listing of inner locations.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        $locations = InnerLocation::all();
        return view('innerlocations.index', compact('locations'));
    }
	public function create()
{
    return view('innerlocations.create');
}

public function store(Request $request)
{
    $request->validate([
        'name' => 'required|string|max:255',
    ]);

    \App\Models\InnerLocation::create([
        'name' => $request->name,
    ]);

    return redirect()->route('innerlocations.index')->with('success', 'Floor added successfully.');
}
	public function edit($id)
{
    $location = InnerLocation::findOrFail($id);
    return view('innerlocations.edit', compact('location'));
}
public function update(Request $request, $id)
{
    $request->validate([
        'name' => 'required|string|max:255',
    ]);

    $location = InnerLocation::findOrFail($id);
    $location->name = $request->input('name');
    $location->save();

    return redirect()->route('innerlocations.index')->with('success', 'Floor updated successfully.');
}
	public function destroy($id)
{
    $location = InnerLocation::findOrFail($id);
    $location->delete();

    return redirect()->route('innerlocations.index')->with('success', 'Floor deleted successfully.');
}


}
