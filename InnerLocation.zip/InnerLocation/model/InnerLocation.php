<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;
use App\Models\Traits\Searchable;
//use App\Presenters\Presentable;

/**
 * Model for Inner Locations.
 *
 * @version v1.0
 */
class InnerLocation extends Model
{
    use Searchable;

    protected $table = 'inner_locations';

    public $timestamps = false; // Assuming there are no created_at/updated_at columns

    protected $fillable = [
        'name',
    ];

  //  protected $presenter = \App\Presenters\InnerLocationPresenter::class;

    /**
     * Scope a query to filter by name (basic example).
     *
     * @param  Builder  $query
     * @param  string  $term
     * @return Builder
     */
    public function scopeSearchByName(Builder $query, string $term): Builder
    {
        return $query->where('name', 'like', '%' . $term . '%');
    }

    /**
     * Advanced text search on the 'name' column
     *
     * @param Builder $query
     * @param array $terms
     * @return Builder
     */
    public function advancedTextSearch(Builder $query, array $terms): Builder
    {
        foreach ($terms as $term) {
            $search_str = '%' . $term . '%';
            $query->orWhere('name', 'like', $search_str);
        }

        return $query;
    }
	 public function workOrders()
    {
        return $this->hasMany(WorkOrder::class);
    }
}
