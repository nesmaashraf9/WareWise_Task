@extends('layouts.default')

@section('title', 'Add Inner Location')

@section('content')
<style>
    .locations-card {
        background: #fff;
        border-radius: 12px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.08);
        padding: 30px;
        max-width: 100%;
        width: 600px;
        margin: auto;
        margin-top: 40px;
    }

    .locations-card h3 {
        font-weight: 600;
        color: #2c3e50;
    }

    .form-label {
        font-weight: 500;
		font-size: 20px;
        color: #34495e;
    }

    .form-control {
        border-radius: 6px;
        border: 1px solid #ced4da;
        width: 100%;
        box-sizing: border-box;
        padding: 10px;
        font-size: 16px;
        background-color: #fff !important;
        transition: border-color 0.3s ease-in-out, box-shadow 0.3s ease-in-out;
    }

    .form-control:focus {
        border-color: #3c8dbc;
        box-shadow: 0 0 0 0.2rem rgba(60, 141, 188, 0.25);
        background-color: #fff !important;
    }

    input:-webkit-autofill,
    input:-webkit-autofill:hover, 
    input:-webkit-autofill:focus {
        box-shadow: 0 0 0px 1000px white inset !important;
        -webkit-box-shadow: 0 0 0px 1000px white inset !important;
    }

    .form-group {
        margin-bottom: 25px;
    }

    .form-actions {
        margin-top: 30px;
    }

    .btn-primary {
        background-color: #3c8dbc;
        border: none;
        padding: 10px 24px;
        border-radius: 6px;
        font-weight: 500;
        color: white;
    }

    .btn-primary:hover {
        background-color: #337ab7;
    }

    .btn-secondary {
        background-color: #6c757d;
        border: none;
        padding: 10px 24px;
        border-radius: 6px;
        font-weight: 500;
        color: white;
        margin-left: 12px;
    }

    .btn-secondary:hover {
        background-color: #5a6268;
    }

    .alert-danger {
        border-radius: 6px;
        padding: 12px;
        background-color: #f8d7da;
        color: #721c24;
        border: 1px solid #f5c6cb;
        margin-bottom: 20px;
    }

    ul.mb-0 {
        padding-left: 20px;
        margin: 0;
    }
</style>

<div class="container">
    <div class="locations-card">
       

        @if ($errors->any())
            <div class="alert alert-danger">
                <ul class="mb-0">
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form action="{{ route('innerlocations.store') }}" method="POST">
            @csrf
            <div class="form-group">
                <label for="name" class="form-label">Floor Name</label>
                <input type="text" class="form-control" id="name" name="name" placeholder="Enter floor name" required>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary">Save</button>
                <a href="{{ route('innerlocations.index') }}" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>
@endsection
