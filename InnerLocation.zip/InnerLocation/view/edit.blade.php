@extends('layouts.default')

@section('title', 'Edit Floor')

@section('content')
<style>
    .locations-card {
        background: #fff;
        border-radius: 12px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.08);
        padding: 30px;
        max-width: 600px;
        margin: auto;
        margin-top: 40px;
    }

    .form-label {
        font-weight: 500;
    }

    .btn {
        margin-top: 15px;
        padding: 10px 20px;
    }

    .btn-secondary {
        margin-left: 10px;
    }
</style>

<div class="container">
    <div class="locations-card">
        <h3>Edit Floor</h3>

        @if ($errors->any())
            <div class="alert alert-danger">
                <ul class="mb-0">
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form action="{{ route('innerlocations.update', $location->id) }}" method="POST">
            @csrf
            @method('PUT')
            <div class="form-group">
                <label for="name" class="form-label">Floor Name</label>
                <input type="text" class="form-control" id="name" name="name" value="{{ $location->name }}" required>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary">Update</button>
                <a href="{{ route('innerlocations.index') }}" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>
@endsection
