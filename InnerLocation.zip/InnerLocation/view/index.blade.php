@extends('layouts.default')

@section('title', 'Hotels Locations')

@section('content')
<style>
    .locations-card {
        background: #fff;
        border-radius: 12px;
        box-shadow: 0 0 10px rgba(0,0,0,0.05);
        padding: 25px;
    }

    .locations-header {
        font-weight: 600;
        font-size: 18px;
        color: #2c3e50;
        margin-bottom: 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .btn-add {
        background-color: #3c8dbc;
        color: white !important;
        border: none;
        padding: 6px 16px;
        border-radius: 6px;
        font-weight: 500;
    }

    .btn-edit {
        background-color: #17a2b8;
        color: white;
        border: none;
        padding: 6px 10px;
        border-radius: 6px;
        margin-right: 6px;
    }

    .btn-delete {
        background-color: #dc3545;
        color: white;
        border: none;
        padding: 6px 10px;
        border-radius: 6px;
    }

    .custom-table {
        width: 100%;
        border-collapse: collapse;
    }

    .custom-table th,
    .custom-table td {
        border: 1px solid #dee2e6;
        padding: 12px;
        text-align: center;
        vertical-align: middle;
    }

    .custom-table thead {
        background-color: #f8f9fa;
        font-weight: bold;
    }

    .custom-table tbody tr:hover {
        background-color: #f1f1f1;
    }
</style>

<div class="container mt-4">
    <div class="locations-card">
        <div class="locations-header">
            <div>
                <i class="fas fa-map-marker-alt text-primary me-2"></i>
                Locations Data Table
            </div>
           <a href="{{ route('innerlocations.create') }}" class="btn-add">Add Floor</a>

        </div>

        @if($locations->isEmpty())
            <p>No locations found.</p>
        @else
            <table class="custom-table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($locations as $index => $location)
                        <tr>
                            <td>{{ $index + 1 }}</td>
                            <td>{{ $location->name }}</td>
                            <td>
    <div style="display: flex; gap: 8px; justify-content: center; align-items: center;">
        <a href="{{ route('innerlocations.edit', $location->id) }}" class="btn-edit">

            <i class="fas fa-edit"></i>
        </a>
       <form action="{{ route('innerlocations.destroy', $location->id) }}" method="POST" onsubmit="return confirm('Are you sure you want to delete this floor?');">
    @csrf
    @method('DELETE')
    <button type="submit" class="btn-delete">
        <i class="fas fa-trash-alt"></i>
    </button>
</form>

    </div>
</td>

							
                        </tr>
                    @endforeach
                </tbody>
            </table>
        @endif
    </div>
</div>
@endsection
