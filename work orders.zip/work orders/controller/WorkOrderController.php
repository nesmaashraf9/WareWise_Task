<?php

namespace App\Http\Controllers;

use App\Models\WorkOrder;
use App\Models\Department;
use App\Models\InnerLocation;
use Illuminate\Http\Request;

class WorkOrderController extends Controller
{
    /**
     * Display a listing of work orders.
     */
   public function index(Request $request)
    {
        $workOrders = WorkOrder::with(['department', 'innerLocation'])->paginate(10);

        return view('work_orders.index', compact('workOrders'));
    }

    /**
     * Show the form for creating a new work order.
     */
   public function create()
{
    $departments = Department::all();
    $locations = InnerLocation::all();
    return view('work_orders.create', compact('departments', 'locations'));
}


    /**
     * Store a newly created work order in storage.
     */
 public function store(Request $request)
{
    $request->validate([
        'department_id' => 'nullable|exists:departments,id',
        'inner_location_id' => 'nullable|exists:locations,id',
        'status' => 'nullable|string',
        'priority' => 'nullable|string',
        'description' => 'nullable|string',
        'attachment' => 'nullable|file|mimes:jpg,jpeg,png,gif,webp,pdf,docx',
    ]);

    $workOrder = new WorkOrder();
    $workOrder->department_id = $request->input('department_id');
    $workOrder->inner_location_id = $request->input('inner_location_id');
    $workOrder->status = $request->input('status');
    $workOrder->priority = $request->input('priority');
    $workOrder->description = $request->input('description');

    // ✅ Save attachment if exists
    if ($request->hasFile('attachment')) {
		$path = $request->file('attachment')->move(public_path('attachments'), $request->file('attachment')->getClientOriginalName());
		$workOrder->attachment = 'attachments/' . $request->file('attachment')->getClientOriginalName();

    }

    $workOrder->save();

    return redirect()->route('work_orders.index')->with('success', 'Work order created successfully!');
}

    /**
     * Display the specified work order.
   
    /**
     * Show the form for editing the specified work order.
     */
    public function edit(WorkOrder $workOrder)
    {
        $departments = Department::all();
        $innerLocations = InnerLocation::all();

        return view('work_orders.edit', compact('workOrder', 'departments', 'innerLocations'));
    }

    /**
     * Update the specified work order in storage.
     */
    public function update(Request $request, WorkOrder $workOrder)
    {
        $validated = $request->validate([
            'department_id' => 'nullable|exists:departments,id',
            'inner_location_id' => 'nullable|exists:inner_locations,id',
            'priority' => 'nullable|string|max:50',
            'status' => 'nullable|string|max:50',
            'attachment' => 'nullable|file|mimes:jpg,jpeg,png,pdf|max:2048',
        ]);

        if ($request->hasFile('attachment')) {
            $validated['attachment'] = $request->file('attachment')->store('attachments', 'public');
        }

        $workOrder->update($validated);

        return redirect()->route('work_orders.index')->with('success', 'Work order updated successfully.');
    }

    /**
     * Remove the specified work order from storage.
     */
    public function destroy(WorkOrder $workOrder)
    {
        $workOrder->delete();

        return redirect()->route('work_orders.index')->with('success', 'Work order deleted successfully.');
    }
}
