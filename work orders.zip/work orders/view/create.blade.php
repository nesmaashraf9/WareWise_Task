@extends('layouts.default')

@section('title', 'Add New Work Order')

@section('content')
<style>
    .create-card {
        background: #fff;
        border-radius: 12px;
        box-shadow: 0 0 10px rgba(0,0,0,0.05);
        padding: 30px;
        max-width: 700px;
        margin: 0 auto;
    }

    .form-title {
        font-size: 20px;
        font-weight: 600;
        color: #2c3e50;
        margin-bottom: 20px;
    }

    .form-group label {
        font-weight: 500;
        color: #333;
    }

    .form-control {
        border-radius: 6px;
    }

    .btn-submit {
        background-color: #3c8dbc;
        color: white;
        font-weight: 500;
        border: none;
        padding: 8px 20px;
        border-radius: 6px;
    }

    .btn-back {
        background-color: #6c757d;
        color: white;
        margin-right: 10px;
        padding: 8px 20px;
        border: none;
        border-radius: 6px;
    }

</style>

<div class="container mt-4">
    <div class="create-card">
        <div class="form-title">
            <i class="fas fa-plus-circle me-2"></i> Add New Work Order
        </div>

        <form action="{{ route('work_orders.store') }}" method="POST" enctype="multipart/form-data">
            @csrf

            <div class="mb-3 form-group">
                <label for="department_id">Department</label>
                <select class="form-control" id="department_id" name="department_id" required>
                    <option value="">Select Department</option>
                    @foreach($departments as $department)
                        <option value="{{ $department->id }}">{{ $department->name }}</option>
                    @endforeach
                </select>
            </div>

            <div class="mb-3 form-group">
                <label for="inner_location_id">Location</label>
                <select class="form-control" id="inner_location_id" name="inner_location_id" required>
                    <option value="">Select Location</option>
                    @foreach($locations as $location)
                        <option value="{{ $location->id }}">{{ $location->name }}</option>
                    @endforeach
                </select>
            </div>

            <div class="mb-3 form-group">
                <label for="status">Status</label>
                <select class="form-control" id="status" name="status" required>
                    <option value="pending">Pending</option>
                    <option value="completed">Completed</option>
                </select>
            </div>

            <div class="mb-3 form-group">
                <label for="priority">Priority</label>
                <select class="form-control" id="priority" name="priority" required>
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                </select>
            </div>

            <div class="mb-3 form-group">
                <label for="description">Description</label>
                <textarea class="form-control" id="description" name="description" rows="3" required></textarea>
            </div>

            <div class="mb-3 form-group">
                <label for="attachment">Attachment (optional)</label>
                <input type="file" class="form-control" id="attachment" name="attachment">
            </div>

            <div class="d-flex justify-content-end">
                <a href="{{ route('work_orders.index') }}" class="btn-back">Back</a>
                <button type="submit" class="btn-submit">Submit</button>
            </div>
        </form>
    </div>
</div>
@endsection
