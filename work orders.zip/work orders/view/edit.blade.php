@extends('layouts.default')

@section('content')
<div class="container mt-4">
    <div class="locations-card">
        <div class="locations-header">
            <div><i class="fas fa-edit me-2"></i> Edit Work Order</div>
           
        </div>

        <form method="POST" action="{{ route('work_orders.update', $workOrder->id) }}" enctype="multipart/form-data">
            @csrf
            @method('PUT')

            <div class="form-group mb-3">
                <label for="department_id">Department</label>
                <select class="form-control" name="department_id" id="department_id">
                    <option value="">-- Select Department --</option>
                    @foreach($departments as $department)
                        <option value="{{ $department->id }}" {{ $workOrder->department_id == $department->id ? 'selected' : '' }}>
                            {{ $department->name }}
                        </option>
                    @endforeach
                </select>
            </div>

            <div class="form-group mb-3">
                <label for="inner_location_id">Location</label>
                <select class="form-control" name="inner_location_id" id="inner_location_id">
                    <option value="">-- Select Location --</option>
                    @foreach($innerLocations as $location)
                        <option value="{{ $location->id }}" {{ $workOrder->inner_location_id == $location->id ? 'selected' : '' }}>
                            {{ $location->name }}
                        </option>
                    @endforeach
                </select>
            </div>

            <div class="form-group mb-3">
                <label for="status">Status</label>
                <select class="form-control" name="status" id="status">
                    <option value="">-- Select Status --</option>
                    <option value="pending" {{ $workOrder->status == 'pending' ? 'selected' : '' }}>Pending</option>
                    <option value="in_progress" {{ $workOrder->status == 'in_progress' ? 'selected' : '' }}>In Progress</option>
                    <option value="completed" {{ $workOrder->status == 'completed' ? 'selected' : '' }}>Completed</option>
                </select>
            </div>

            <div class="form-group mb-3">
                <label for="priority">Priority</label>
                <select class="form-control" name="priority" id="priority">
                    <option value="">-- Select Priority --</option>
                    <option value="low" {{ $workOrder->priority == 'low' ? 'selected' : '' }}>Low</option>
                    <option value="medium" {{ $workOrder->priority == 'medium' ? 'selected' : '' }}>Medium</option>
                    <option value="high" {{ $workOrder->priority == 'high' ? 'selected' : '' }}>High</option>
                </select>
            </div>

            <div class="form-group mb-3">
                <label for="description">Description</label>
                <textarea class="form-control" name="description" id="description" rows="3">{{ old('description', $workOrder->description) }}</textarea>
            </div>

            <div class="form-group mb-4">
                <label for="attachment">Attachment (Optional)</label>
                <input type="file" class="form-control" name="attachment" id="attachment">
                @if($workOrder->attachment)
                    <small class="form-text text-muted">
                        Current: <a href="{{ asset('storage/' . $workOrder->attachment) }}" target="_blank">View</a>
                    </small>
                @endif
            </div>

            <button type="submit" class="btn btn-success">Update Work Order</button>
        </form>
    </div>
</div>
@endsection
