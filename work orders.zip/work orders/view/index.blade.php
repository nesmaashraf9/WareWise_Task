@extends('layouts.default')

@section('content')
<style>
    .locations-card {
        background: #fff;
        border-radius: 12px;
        box-shadow: 0 0 10px rgba(0,0,0,0.05);
        padding: 25px;
    }

    .locations-header {
        font-weight: 600;
        font-size: 20px;
        margin-bottom: 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        color: #2c3e50;
    }

    .btn-add {
        background-color: #3c8dbc;
        color: white !important;
        border: none;
        padding: 6px 16px;
        border-radius: 6px;
        font-weight: 500;
    }

    .btn-edit {
        background-color: #17a2b8;
        color: white;
        border: none;
        padding: 6px 10px;
        border-radius: 6px;
    }

    .btn-delete {
        background-color: #dc3545;
        color: white;
        border: none;
        padding: 6px 10px;
        border-radius: 6px;
    }

    .custom-table {
        width: 100%;
        border-collapse: collapse;
    }

    .custom-table th,
    .custom-table td {
        border: 1px solid #dee2e6;
        padding: 12px;
        text-align: center;
        vertical-align: middle;
        color: #2c3e50;
    }

    .custom-table thead {
        background-color: #f8f9fa;
        font-weight: bold;
    }

    .custom-table tbody tr:hover {
        background-color: #f1f1f1;
    }

    .badge-status, .badge-priority {
        display: inline-block;
        padding: 5px 10px;
        border-radius: 6px;
        font-size: 13px;
        color: white;
        font-weight: 500;
    }
</style>

<div class="container mt-4">
    <div class="locations-card">
        <div class="locations-header">
            <div>
                <i class="fas fa-tasks me-2"></i> Work Orders
            </div>
            <a href="{{ route('work_orders.create') }}" class="btn-add">
                <i class="fas fa-plus"></i> Add Work Order
            </a>
        </div>

        <div class="table-responsive">
            <table class="custom-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Department</th>
                        <th>Location</th>
                        <th>Status</th>
                        <th>Priority</th>
                        <th>Description</th>
                        <th>Attachment</th>
                        <th>Created At</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($workOrders as $workOrder)
                        <tr>
                            <td>{{ $workOrder->id }}</td>
                            <td>{{ optional($workOrder->department)->name ?? '❌ Not assigned' }}</td>
                            <td>{{ optional($workOrder->innerLocation)->name ?? '❌ Not assigned' }}</td>
                            <td>
                                <span class="badge-status" style="background-color:
                                    {{ $workOrder->status === 'completed' ? '#28a745' : ($workOrder->status === 'pending' ? '#ffc107' : '#6c757d') }};">
                                    {{ $workOrder->status ?? 'Not set' }}
                                </span>
                            </td>
                            <td>
                                <span class="badge-priority" style="background-color:
                                    {{ $workOrder->priority === 'high' ? '#dc3545' : ($workOrder->priority === 'medium' ? '#fd7e14' : '#17a2b8') }};">
                                    {{ $workOrder->priority ?? 'Not set' }}
                                </span>
                            </td>
                            <td>{{ $workOrder->description ?? 'No description' }}</td>
							<td>
								@if($workOrder->attachment)
								@php
								$ext = pathinfo($workOrder->attachment, PATHINFO_EXTENSION);
								$isImage = in_array(strtolower($ext), ['jpg', 'jpeg', 'png', 'gif', 'webp']);
								$attachmentUrl = asset($workOrder->attachment);
								@endphp
								<div style="display: flex; flex-direction: column; align-items: center; gap: 6px;">
									@if($isImage)
									<img src="{{ $attachmentUrl }}" alt="Attachment" style="max-width: 90px; border-radius: 6px;">
									@else
									<i class="fas fa-file-alt fa-2x text-secondary"></i>
									@endif

									<div style="display: flex; gap: 10px;">
										<a href="{{ $attachmentUrl }}" target="_blank" title="View">
											<i class="fas fa-eye text-primary"></i>
										</a>
										<a href="{{ $attachmentUrl }}" download title="Download">
											<i class="fas fa-download text-success"></i>
										</a>
									</div>
								</div>
								@else
								<span>No attachment</span>
								@endif
							</td>

                            <td>{{ $workOrder->created_at ? $workOrder->created_at->format('Y-m-d H:i') : 'N/A' }}</td>
                            <td>
                                <div style="display: flex; gap: 8px; justify-content: center; align-items: center;">
                                    <a href="{{ route('work_orders.edit', $workOrder->id) }}" class="btn-edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <form action="{{ route('work_orders.destroy', $workOrder->id) }}" method="POST" onsubmit="return confirm('Are you sure?');">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn-delete">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>

        <div class="d-flex justify-content-center mt-3">
            {{ $workOrders->links() }}
        </div>
    </div>
</div>
@endsection
